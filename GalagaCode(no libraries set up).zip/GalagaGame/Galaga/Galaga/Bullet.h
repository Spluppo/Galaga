#pragma once
#include <SFML/Graphics.hpp>
#include <string>
#include <cmath>
#include "SpriteObject.h"

class Bullet
{
public:	
	float m_speed = 400;
	sf::Vector2f m_position;
	SpriteObject m_spriteObject;

	bool operator == (const Bullet& b) const { return m_position == b.m_position; }
	bool operator != (const Bullet& b) const { return !operator== (b); }


	void Move(float deltaTime)
	{
		m_position.y += m_speed * deltaTime;
		m_spriteObject.m_sprite.setPosition(m_position.x, m_position.y);
	}

private:
	static sf::Vector2f size;
};
