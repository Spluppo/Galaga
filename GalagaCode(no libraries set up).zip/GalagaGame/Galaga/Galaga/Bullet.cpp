#include "App.h"
#include "Distance.h"

// Moves bullets across screen
void::App::BulletUpdate()
{
	if (&bullets != NULL)
	{
		//std::cout << bullets->size() << std::endl;
		// Go through every bullet in the 'bullets' list
		for (std::list<Bullet>::iterator it = bullets.begin(); it != bullets.end(); it++)
		{
			// Collision Checks
			if (BulletCollision(*it))
			{
				bullets.erase(it);
				std::cout << "Bullet Deleted" << std::endl;
				break;
			}

			// Move
			(*it).Move(deltaTime);
			
			// Render
			(*it).m_spriteObject.SetPosition((*it).m_position.x, window.getSize().y - (*it).m_position.y);
		}
	}
}

bool::App::BulletCollision(Bullet b)
{
	// Check if bullet is in range of an enemy
	for (std::list<Enemy>::iterator it = enemies.begin(); it != enemies.end(); it++)
	{
		// if distance is smaller than both the bullet's radius + the enemy's radius combined, they've hit.
		// Bullets get compensated for being on the bottom of the screen.
		if (Distance(b.m_position.x, window.getSize().y - b.m_position.y, (*it).GetPosition().x, (*it).GetPosition().y)
			<= b.m_spriteObject.m_sprite.getLocalBounds().width / 2 + (*it).m_radius)
		{
			score += (*it).m_points;
			scoreText.m_text.setString(std::to_string(score));
			enemies.erase(it);
			std::cout << "Enemy Killed" << std::endl;
			return true;
		}
	}

	// Check for whether the bullet has gone off screen
	if (b.m_position.y > window.getSize().y)
	{
		return true;
	}

	return false;
}

Bullet App::InitialiseBullet()
{
	Bullet b;
	b.m_spriteObject.m_scale = sf::Vector2f(0.5f, 1.5f);
	b.m_position = sf::Vector2f(player.GetPosition().x, player.GetPosition().y);
	b.m_spriteObject.InitialiseTexture("Assets/circle.png");
	return b;
}