#include "App.h"

int main()
{
	App game("Galaga", 440, 560, 32);

	if (!game.Init())
	{
		printf("Game did not start");

		return EXIT_FAILURE;
	}
	else
	{
		game.Run();
	}
	return EXIT_SUCCESS;
}