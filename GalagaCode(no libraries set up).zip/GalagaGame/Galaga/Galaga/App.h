#pragma once
#include "SFML/Graphics.hpp"
#include "SFML/Audio.hpp"
#include "Player.h"
#include "Bullet.h"
#include "Enemy.h"
#include "TextObject.h"
#include <list>
#include <iterator>

class App
{
public:
	sf::Event				event;
	sf::RenderWindow		window;
	sf::View				view;
	sf::Clock				clock;

	bool					paused;
	float					deltaTime;

	Player					player;
	float					shotDelay;
	std::list<Bullet>		bullets;

	std::list<Enemy>		enemies;
	float					enemySpawnTimer;
	float					enemyDelay;

	TextObject				scoreHeader;
	TextObject				scoreText;
	TextObject				highscoreHeader;
	TextObject				highscoreText;
	TextObject				instructionsText;
	sf::Font				font;
	int						score;

	App(const char* Name, int ScreenWidth, int ScreenHeight, int ScreenBpp);

	~App();

	bool Init();
	void HandleEvents();
	void Draw();
	void Update();
	void Run();

private:
	//App Functions
	Bullet InitialiseBullet();
	bool BulletCollision(Bullet bullet);
	void InitialisePlayer();
	void PlayerUpdate();
	void BulletUpdate();
	void InitialiseText();
	void EnemyUpdate();
	bool EnemyCollision(Enemy enemy);
	void SpawnEnemy();
	Enemy InitialiseEnemy();
};