#pragma once
#include <SFML/Graphics.hpp>
#include "health.h"
#include "SpriteObject.h"
#include "App.h"
#include "Bullet.h"

class Player
{
private:
	sf::Vector2f m_position;
	int m_speed = 200;

	Health m_health;
	SpriteObject m_spriteObject;

public:
	Player() : m_position(0, 0) {}
	Player(const sf::Vector2f& position) : m_position(position) {}

	const sf::Vector2f& GetPosition() const { return m_position; }
	SpriteObject& GetSpriteObject() { return m_spriteObject; }
	const Health& GetHealth() const { return m_health; }

	float m_shotDelay = 0.25f;
	float m_radius;

	void SetPosition(float x, float y) { m_position = sf::Vector2f(x, y); }

	void Move(float deltaTime)
	{
		sf::Vector2f direction = sf::Vector2f(0, 0);

		// Vertical Movement - positive y moves up, negative moves down 
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up) || sf::Keyboard::isKeyPressed(sf::Keyboard::W))
		{
			direction.y = 1;
		}
		else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down) || sf::Keyboard::isKeyPressed(sf::Keyboard::S))
		{
			direction.y = -1;
		}

		// Horizontal Movement - positive x moves right, negative moves left 
		if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left) || sf::Keyboard::isKeyPressed(sf::Keyboard::A))
		{
			direction.x = -1;
		}
		else if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right) || sf::Keyboard::isKeyPressed(sf::Keyboard::D))
		{
			direction.x = 1;
		}

		m_position.x += m_speed * direction.x * deltaTime;
		m_position.y += m_speed * direction.y * deltaTime;
	}
};