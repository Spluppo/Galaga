#include "App.h"
#include "Origin.h"
//#include "Distance.h"

void App::PlayerUpdate()
{
	// Movement //
	player.Move(deltaTime);

	// Check Collisions with window borders
	//// Check Horizontal
	if (player.GetPosition().x - player.m_radius < 0)
	{
		player.SetPosition(1 + player.m_radius, player.GetPosition().y);
	}
	else if (player.GetPosition().x + player.m_radius > window.getSize().x)
	{
		player.SetPosition(window.getSize().x - 1 - player.m_radius, player.GetPosition().y);
	}
	////// Check Vertical
	if (player.GetPosition().y - player.m_radius < 0)
	{
		player.SetPosition(player.GetPosition().x, 1 + player.m_radius);
	}
	else if (player.GetPosition().y + player.m_radius > window.getSize().y)
	{
		player.SetPosition(player.GetPosition().x, window.getSize().y - 1 - player.m_radius);
	}

	
	// Update Sprite to player's position
	// Since the origin is in the top left corner of the window, I set it here so that I can have access to the window's size and adjust from there.
	player.GetSpriteObject().SetPosition(player.GetPosition().x, window.getSize().y - player.GetPosition().y);


	// Shooting //
	shotDelay -= deltaTime;
	//std::cout << player.m_shotDelay << std::endl;
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::J) || sf::Keyboard::isKeyPressed(sf::Keyboard::X))
	{
		if (shotDelay <= 0.0f)
		{
			shotDelay = player.m_shotDelay;
			// If the player shoots, create a bullet and add it to the bullets list.
			bullets.push_back(InitialiseBullet());
			
		}
	}

}

void App::InitialisePlayer()
{
	sf::Vector2f windowSize = sf::Vector2f((float)window.getSize().x, (float)window.getSize().y);
	player.SetPosition(windowSize.x / 2, windowSize.y / 10);

	player.GetSpriteObject().InitialiseTexture("Assets/GalagaShip.png");
	player.GetSpriteObject().m_sprite.setScale(2, 2);
	player.GetSpriteObject().SetPosition(windowSize.x / 2, windowSize.y - windowSize.y / 10);
	player.m_radius = player.GetSpriteObject().m_sprite.getGlobalBounds().width / 2;

}