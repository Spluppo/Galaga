#include <iostream>
#include <string>
#include <fstream>
#include "App.h"
#include "Player.h"


// constructor
App::App(const char* Title, int ScreenWidth, int ScreenHeight, int ScreenBpp)	
{
	window.create(sf::VideoMode(ScreenWidth, ScreenHeight, ScreenBpp), Title);

	window.setFramerateLimit(0);
	view = window.getDefaultView();
}

// destructor
App::~App()
{
	// release memory
}

bool App::Init()
{
	// initialise App data members
	InitialiseText();
	InitialisePlayer();

	return true;
}

void App::Update()
{
	// update
	deltaTime = clock.restart().asSeconds();

	PlayerUpdate();
	BulletUpdate();
	EnemyUpdate();
}

void App::Draw()
{
	window.clear();
	window.setView(view);

	// draw sprites, text, etc.
	window.draw(highscoreHeader.m_text);
	window.draw(highscoreText.m_text);
	window.draw(scoreHeader.m_text);
	window.draw(scoreText.m_text);
	window.draw(instructionsText.m_text);

	// Loop through bullets and draw them	
	for (std::list<Bullet>::iterator it = bullets.begin(); it != bullets.end(); it++)
	{
		window.draw(it->m_spriteObject.m_sprite);
	}

	// Loop through enemies and draw them	
	for (std::list<Enemy>::iterator it = enemies.begin(); it != enemies.end(); it++)
	{
		window.draw(it->GetSpriteObject().m_sprite);
	}

	window.draw(player.GetSpriteObject().m_sprite);

	window.display();
}

void App::Run()
{
	while (window.isOpen())
	{
		while (window.pollEvent(event))
		{
			HandleEvents();
		}
		Update();
		Draw();
	}
}

void App::InitialiseText()
{
	if (!font.loadFromFile("Assets/PressStart2P.ttf"))
	{
		std::cout << "Could not find font\n\n";
	}

	highscoreHeader.InitialiseTextObject(sf::String("HIGHSCORE"), sf::Color::Red, 12, CENTER);
	highscoreHeader.m_text.setPosition(sf::Vector2f((float)window.getSize().x / 2, (float)window.getSize().y / 24));
	highscoreHeader.m_text.setFont(font);
	highscoreText.InitialiseTextObject(sf::String("00000"), sf::Color::White, 12, CENTER);
	highscoreText.m_text.setPosition(sf::Vector2f((float)window.getSize().x / 2, ((float)window.getSize().y / 24) * 2));
	highscoreText.m_text.setFont(font);

	scoreHeader.InitialiseTextObject(sf::String("1UP"), sf::Color::Red, 12, LEFT);
	scoreHeader.m_text.setPosition(sf::Vector2f((float)window.getSize().x / 24, (float)window.getSize().y / 24));
	scoreHeader.m_text.setFont(font);
	scoreText.InitialiseTextObject(sf::String("00000"), sf::Color::White, 12, LEFT);
	scoreText.m_text.setPosition(sf::Vector2f((float)window.getSize().x / 24, ((float)window.getSize().y / 24) * 2));
	scoreText.m_text.setFont(font);

	instructionsText.InitialiseTextObject(sf::String("WASD - MOVE\nJ - SHOOT"), sf::Color(80, 80, 80), 12, LEFT);
	instructionsText.m_text.setPosition(sf::Vector2f((float)window.getSize().x / 24, ((float)window.getSize().y / 24) * 22));
	instructionsText.m_text.setFont(font);
}