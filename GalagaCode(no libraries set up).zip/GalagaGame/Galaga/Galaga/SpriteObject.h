#pragma once
#include <iostream>
#include <SFML/Graphics.hpp>
#include <string>
#include "Origin.h"

struct SpriteObject
{
	sf::Sprite m_sprite;
	sf::Texture m_texture;

	sf::Vector2f m_scale;
	sf::Vector2f m_size;

	Origin m_origin = CENTER;

	void SetPosition(float x, float y) { m_sprite.setPosition(sf::Vector2f(x, y)); }

	void InitialiseTexture(sf::String texName)
	{
		if (!m_texture.loadFromFile(texName))
		{
			std::cout << "Could not find texture\n\n" << std::endl;
		}
		// Apply texture to sprite
		m_sprite.setTexture(m_texture);

		switch (m_origin)
		{
		case LEFT:
			m_sprite.setOrigin(0, m_sprite.getLocalBounds().height / 2);
			break;
		case CENTER:
			m_sprite.setOrigin(m_sprite.getLocalBounds().width / 2, m_sprite.getLocalBounds().height / 2);
			break;
		case RIGHT:
			m_sprite.setOrigin(m_sprite.getLocalBounds().width, m_sprite.getLocalBounds().height / 2);
			break;
		default:
			m_sprite.setOrigin(0, m_sprite.getLocalBounds().height / 2);
		}
	}

};