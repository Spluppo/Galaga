#include "App.h"

void App::HandleEvents()
{
	while (window.pollEvent(event))
	
	if (event.type == sf::Event::Closed)
	{
		window.close();
	}

	// Controls
	if (sf::Keyboard::isKeyPressed(sf::Keyboard::Space))
	{
		paused = !paused;
	}
}