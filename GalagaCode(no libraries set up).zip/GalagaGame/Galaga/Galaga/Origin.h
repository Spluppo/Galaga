#pragma once
enum Origin : unsigned char
{
	LEFT, CENTER, RIGHT
};