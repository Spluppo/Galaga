#pragma once
#include <SFML/Graphics.hpp>
#include "health.h"
#include "SpriteObject.h"
#include "App.h"
#include "Bullet.h"

class Enemy
{
private:
	sf::Vector2f m_position;
	int m_speed = 100;

	Health m_health;
	SpriteObject m_spriteObject;

public:
	Enemy() : m_position(0, 0) {}
	Enemy(const sf::Vector2f& position) : m_position(position) {}

	const sf::Vector2f& GetPosition() const { return m_position; }
	SpriteObject& GetSpriteObject() { return m_spriteObject; }
	const Health& GetHealth() const { return m_health; }

	float m_shotDelay = 4.0f;
	float m_radius = m_spriteObject.m_sprite.getGlobalBounds().width;
	int m_points = 50;

	void SetPosition(float x, float y) { m_position = sf::Vector2f(x, y); }
	void SetSpeed(int x) { m_speed = x; }
	const int& GetPoints() const { return m_points; }

	void Move(float deltaTime)
	{
		sf::Vector2f direction = sf::Vector2f(0, 1);

		m_position.x += m_speed * direction.x * deltaTime;
		m_position.y += m_speed * direction.y * deltaTime;
	}
};