#pragma once
#include <SFML/Graphics.hpp>
#include <string>
#include "Origin.h"

struct TextObject
{
	sf::Text m_text;
	Origin m_origin;

	void InitialiseTextObject(sf::String txt, sf::Color color, int size, Origin SetOriginCenter)
	{
		m_text.setString(txt);
		m_text.setFillColor(color);
		m_text.setCharacterSize(size);

		switch (m_origin)
		{
		case LEFT:
			m_text.setOrigin(0, m_text.getLocalBounds().height / 2);
			break;
		case CENTER:
			m_text.setOrigin(m_text.getLocalBounds().width / 2, m_text.getLocalBounds().height / 2);
			break;
		case RIGHT:
			m_text.setOrigin(m_text.getLocalBounds().width, m_text.getLocalBounds().height / 2);
			break;
		default:
			m_text.setOrigin(0, m_text.getLocalBounds().height / 2);
		}
	}
			
};
