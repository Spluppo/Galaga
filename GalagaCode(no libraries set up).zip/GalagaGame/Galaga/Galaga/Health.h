#pragma once
struct Health
{
private:
	int m_amount;

public:

	// Hit function to update health. Returns true when "dead".
	int Hit()
	{
		m_amount--;
		if (m_amount <= 0)
		{
			return 1;
		}
	}
};