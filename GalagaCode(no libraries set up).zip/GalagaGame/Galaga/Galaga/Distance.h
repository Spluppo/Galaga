#pragma once
#include <cmath>

// returns the absolute distance between two points
float Distance(float x1, float y1, float x2, float y2)
{
	const float xDiff = x2 - x1;
	const float yDiff = y2 - y1;
	return std::abs(std::sqrt(xDiff * xDiff + yDiff * yDiff));
}