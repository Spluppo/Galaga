#include "App.h"
#include "RandomRange.h"

void::App::EnemyUpdate()
{
	enemySpawnTimer -= deltaTime;
	if (enemySpawnTimer <= 0)
	{
		enemySpawnTimer = enemyDelay;
		enemyDelay = (float)RandomRange(1, 3);
		SpawnEnemy();
	}

	if (&enemies != NULL)
	{
		//std::cout << bullets->size() << std::endl;
		// Go through every enemy in the 'enemies' list
		for (std::list<Enemy>::iterator it = enemies.begin(); it != enemies.end(); it++)
		{
			// Move
			(*it).Move(deltaTime);

			//std::cout << "Enemy X:" << (*it).GetPosition().x << "\nEnemy Y:" << (*it).GetPosition().y << std::endl;

			// Render
			(*it).GetSpriteObject().SetPosition((*it).GetPosition().x, (*it).GetPosition().y);
		}
	}
}

void::App::SpawnEnemy()
{
	enemies.push_back(InitialiseEnemy());
	
	//std::cout << "Spawned a new enemy" << std::endl;
}

Enemy App::InitialiseEnemy()
{
	Enemy enemy;

	enemy.SetPosition(RandomRange(0 + enemy.m_radius, window.getSize().x - enemy.m_radius), 0);
	enemy.SetSpeed(RandomRange(80, 120));
	enemy.GetSpriteObject().SetPosition(enemy.GetPosition().x, enemy.GetPosition().y);
	enemy.GetSpriteObject().m_sprite.setColor(sf::Color::Red);
	enemy.GetSpriteObject().InitialiseTexture("Assets/GalagaEnemy.png");
	return enemy;
}